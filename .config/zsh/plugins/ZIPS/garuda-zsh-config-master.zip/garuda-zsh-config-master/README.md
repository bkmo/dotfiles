# garuda-zsh-config

zsh config for garudalinux