# omz-git

[Oh My Zsh](https://ohmyz.sh)'z [git plugin](https://github.com/ohmyzsh/ohmyzsh/tree/master/plugins/git) packaged to be standalone.
