# ZSH sudo plugin

Extracted from oh-my-zsh

This plugin toggles "sudo" before the current/previous command by pressing [ESC][ESC] in emacs-mode or vi-command mode.
